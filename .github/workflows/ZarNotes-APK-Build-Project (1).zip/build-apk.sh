#!/usr/bin/env bash
./gradlew assembleDebug
echo "APK created at app/build/outputs/apk/debug/ZarNotes-debug-v1.0.0.apk"
