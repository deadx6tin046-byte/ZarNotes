# ZarNotes — APK Build & Sideload Guide
**Package**: `com.alphabx.zarnotes`
**Target**: Standalone Android Application Package (`.apk`)
**Strict Format**: **NO Android App Bundle (`.aab`)** — Only Direct Installable `.apk`

## Quick Commands
- **Build Test APK**: `./gradlew assembleDebug`
- **Build Release APK**: `./gradlew assembleRelease`
- **Install on USB Phone**: `adb install -r app/build/outputs/apk/debug/ZarNotes-debug-v1.0.0.apk`

## Output Paths
- Debug APK: `app/build/outputs/apk/debug/ZarNotes-debug-v1.0.0.apk`
- Release APK: `app/build/outputs/apk/release/ZarNotes-release-v1.0.0.apk`
