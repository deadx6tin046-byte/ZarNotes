package com.alphabx.zarnotes.domain.model

data class User(
    val id: String = "",
    val email: String = "",
    val displayName: String = "",
    val photoUrl: String? = null,
    val coins: Int = 320,
    val noteSlotsLimit: Int = 100,
    val storageLimitGb: Double = 1.0,
    val notesCount: Int = 84
)
