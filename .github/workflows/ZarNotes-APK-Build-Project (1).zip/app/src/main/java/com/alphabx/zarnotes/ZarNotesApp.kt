package com.alphabx.zarnotes

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class ZarNotesApp : Application()
