package com.alphabx.zarnotes.presentation.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import com.alphabx.zarnotes.presentation.auth.*
import com.alphabx.zarnotes.presentation.editor.NoteEditorScreen
import com.alphabx.zarnotes.presentation.notes.NotesListScreen
import com.alphabx.zarnotes.presentation.profile.ProfileScreen
import com.alphabx.zarnotes.presentation.search.SearchScreen
import com.alphabx.zarnotes.presentation.shop.CoinShopScreen

@Composable
fun ZarNotesNavGraph(
    navController: NavHostController = rememberNavController(),
    startDestination: String = Screen.NotesList.route
) {
    NavHost(navController = navController, startDestination = startDestination) {
        composable(Screen.Login.route) {
            LoginScreen(
                onNavigateToRegister = { navController.navigate(Screen.Register.route) },
                onLoginSuccess = { navController.navigate(Screen.NotesList.route) }
            )
        }
        composable(Screen.Register.route) {
            RegisterScreen(
                onNavigateBack = { navController.popBackStack() },
                onRegisterSuccess = { navController.navigate(Screen.NotesList.route) }
            )
        }
        composable(Screen.NotesList.route) { NotesListScreen(onNavigateToEditor = { id -> navController.navigate("note_editor/$id") }) }
        composable(Screen.Search.route) { SearchScreen(onNavigateToEditor = { id -> navController.navigate("note_editor/$id") }) }
        composable(Screen.CoinShop.route) { CoinShopScreen() }
        composable(Screen.Profile.route) {
            ProfileScreen(onSignOut = {
                navController.navigate(Screen.Login.route) { popUpTo(0) { inclusive = true } }
            })
        }
    }
}
