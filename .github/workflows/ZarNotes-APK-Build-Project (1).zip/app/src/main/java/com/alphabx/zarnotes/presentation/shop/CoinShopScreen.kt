package com.alphabx.zarnotes.presentation.shop

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.alphabx.zarnotes.domain.model.ShopItem

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CoinShopScreen(
    viewModel: CoinShopViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF7F8FD)) {
        Column(
            modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
        ) {
            TopAppBar(
                title = { Text("Coin Shop", fontWeight = FontWeight.Bold, fontSize = 22.sp) },
                actions = { IconButton(onClick = {}) { Icon(Icons.Default.MoreVert, contentDescription = null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )

            // Usage Card with 84% gauge
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Row(modifier = Modifier.padding(24.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(80.dp)) {
                        Canvas(modifier = Modifier.size(76.dp)) {
                            drawArc(Color(0xFFE2E8F0), -90f, 360f, false, style = Stroke(16f, cap = StrokeCap.Round))
                            drawArc(Color(0xFF3B49DF), -90f, 302.4f, false, style = Stroke(16f, cap = StrokeCap.Round))
                        }
                        Text("84%", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(20.dp))
                    Column {
                        Text("${uiState.user.coins} coins", fontSize = 26.sp, fontWeight = FontWeight.Bold)
                        Text("${uiState.user.notesCount} of ${uiState.user.noteSlotsLimit} notes used", color = Color(0xFF64748B), fontSize = 14.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Quick Upgrades
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Card(modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFEEF2FF)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = Color(0xFF3B49DF))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("+50 note slots", fontWeight = FontWeight.SemiBold)
                        Text("120 coins", color = Color(0xFF64748B), fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.spendCoinsOnItem(ShopItem.ExtraNoteSlots) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B49DF))) {
                            Text("Spend coins", fontSize = 13.sp)
                        }
                    }
                }
                Card(modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(0xFFEEF2FF)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Cloud, contentDescription = null, tint = Color(0xFF3B49DF))
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("+1 GB storage", fontWeight = FontWeight.SemiBold)
                        Text("200 coins", color = Color(0xFF64748B), fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(onClick = { viewModel.spendCoinsOnItem(ShopItem.ExtraStorage) }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B49DF))) {
                            Text("Spend coins", fontSize = 13.sp)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
            Text("Buy coins", fontWeight = FontWeight.Bold, fontSize = 20.sp)
            Text("Get more coins to unlock more storage and note limits.", color = Color(0xFF64748B))

            // 105 ($1.05), 205 ($2.05), 305 ($3.05), 405 ($4.05), 505 ($5.05), Starter ($0.99), Plus ($3.99), Pro ($7.99)
            val coinPacks = listOf(
                CoinProduct("coins_99_pack", "99 Coins Pack", 99, "$0.99", badge = "99 Cents"),
                CoinProduct("coins_105_pack", "105 Coins Pack", 105, "$1.05", badge = "Special"),
                CoinProduct("coins_205_pack", "205 Coins Pack", 205, "$2.05", badge = "Popular"),
                CoinProduct("coins_305_pack", "305 Coins Pack", 305, "$3.05", badge = "Value Pack"),
                CoinProduct("coins_405_pack", "405 Coins Pack", 405, "$4.05", badge = "Pro Choice"),
                CoinProduct("coins_505_pack", "505 Coins Pack", 505, "$5.05", badge = "Best Deal"),
                CoinProduct("coins_starter_100", "Starter Pack", 100, "$0.99"),
                CoinProduct("coins_plus_500", "Plus Pack", 500, "$3.99"),
                CoinProduct("coins_pro_1200", "Pro Vault", 1200, "$7.99")
            )
            // Rendered with Google Play Billing launch
        }
    }
}
