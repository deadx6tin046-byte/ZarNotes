package com.alphabx.zarnotes.data.billing

import android.app.Activity
import android.content.Context
import com.alphabx.zarnotes.domain.model.CoinProduct
import com.android.billingclient.api.*
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class BillingManager @Inject constructor(
    @ApplicationContext private val context: Context
) : PurchasesUpdatedListener {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var billingClient: BillingClient? = null

    private val _availableProducts = MutableStateFlow<List<CoinProduct>>(listOf(
        CoinProduct("coins_99_pack", "99 Coins Pack", 99, "$0.99", badge = "99 Cents"),
        CoinProduct("coins_105_pack", "105 Coins Pack", 105, "$1.05", badge = "Special"),
        CoinProduct("coins_205_pack", "205 Coins Pack", 205, "$2.05", badge = "Popular"),
        CoinProduct("coins_305_pack", "305 Coins Pack", 305, "$3.05", badge = "Value Pack"),
        CoinProduct("coins_405_pack", "405 Coins Pack", 405, "$4.05", badge = "Pro Choice"),
        CoinProduct("coins_505_pack", "505 Coins Pack", 505, "$5.05", badge = "Best Deal"),
        CoinProduct("coins_starter_100", "Starter Pack", 100, "$0.99"),
        CoinProduct("coins_plus_500", "Plus Pack", 500, "$3.99"),
        CoinProduct("coins_pro_1200", "Pro Vault", 1200, "$7.99")
    ))
    val availableProducts: StateFlow<List<CoinProduct>> = _availableProducts.asStateFlow()

    private val _purchaseSuccessEvents = MutableSharedFlow<CoinProduct>()
    val purchaseSuccessEvents: SharedFlow<CoinProduct> = _purchaseSuccessEvents.asSharedFlow()

    fun startBillingConnection() {
        billingClient = BillingClient.newBuilder(context)
            .setListener(this)
            .enablePendingPurchases()
            .build()

        billingClient?.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(res: BillingResult) {
                if (res.responseCode == BillingClient.BillingResponseCode.OK) {
                    // Query in-app product details
                }
            }
            override fun onBillingServiceDisconnected() {}
        })
    }

    fun launchPurchase(activity: Activity, product: CoinProduct) {
        scope.launch {
            _purchaseSuccessEvents.emit(product)
        }
    }

    override fun onPurchasesUpdated(res: BillingResult, purchases: List<Purchase>?) {
        if (res.responseCode == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (purchase in purchases) {
                // Acknowledge & consume
                val consumeParams = ConsumeParams.newBuilder()
                    .setPurchaseToken(purchase.purchaseToken)
                    .build()
                billingClient?.consumeAsync(consumeParams) { _, _ -> }
            }
        }
    }
}
