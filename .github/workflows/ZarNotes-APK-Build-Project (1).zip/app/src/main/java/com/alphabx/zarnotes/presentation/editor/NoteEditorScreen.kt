package com.alphabx.zarnotes.presentation.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun NoteEditorScreen(
    onNavigateBack: () -> Unit,
    viewModel: NoteEditorViewModel = hiltViewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF7F8FD)) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                TopAppBar(
                    title = { Text("Edit note", fontWeight = FontWeight.SemiBold) },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.deleteNote() }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete")
                        }
                        IconButton(onClick = {}) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
                )

                Surface(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    shape = RoundedCornerShape(28.dp),
                    color = Color.White
                ) {
                    Column(modifier = Modifier.fillMaxSize().padding(24.dp)) {
                        BasicTextField(
                            value = uiState.title,
                            onValueChange = { viewModel.onTitleChanged(it) },
                            textStyle = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.Bold),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        BasicTextField(
                            value = uiState.content,
                            onValueChange = { viewModel.onContentChanged(it) },
                            textStyle = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
                            modifier = Modifier.fillMaxWidth().weight(1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Tag Chips
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    uiState.tags.forEach { tag ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(20.dp))
                                .background(Color(0xFFE8EDFF))
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                        ) {
                            Text(tag, color = Color(0xFF312E81), fontWeight = FontWeight.Medium)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Synced info
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 24.dp)) {
                    Icon(Icons.Default.CloudDone, contentDescription = null, tint = Color(0xFF64748B))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("${uiState.syncStatusText} - ${uiState.wordCount} words", color = Color(0xFF64748B))
                }
            }

            // Done Button
            Button(
                onClick = { viewModel.saveNote() },
                modifier = Modifier.align(Alignment.BottomEnd).padding(20.dp),
                shape = RoundedCornerShape(24.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B49DF))
            ) {
                Text("Done", fontWeight = FontWeight.SemiBold, color = Color.White)
            }
        }
    }
}
