package com.alphabx.zarnotes.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.alphabx.zarnotes.domain.model.Note

@Entity(tableName = "notes")
data class NoteEntity(
    @PrimaryKey
    val id: String,
    val userId: String,
    val title: String,
    val content: String,
    val tagsString: String,
    val isPinned: Boolean,
    val colorHex: String,
    val wordCount: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val isSynced: Boolean
) {
    fun toDomain(): Note = Note(
        id = id,
        userId = userId,
        title = title,
        content = content,
        tags = if (tagsString.isBlank()) emptyList() else tagsString.split(",").map { it.trim() },
        isPinned = isPinned,
        colorHex = colorHex,
        wordCount = wordCount,
        createdAt = createdAt,
        updatedAt = updatedAt,
        isSynced = isSynced
    )

    companion object {
        fun fromDomain(note: Note): NoteEntity = NoteEntity(
            id = note.id,
            userId = note.userId,
            title = note.title,
            content = note.content,
            tagsString = note.tags.joinToString(","),
            isPinned = note.isPinned,
            colorHex = note.colorHex,
            wordCount = note.wordCount,
            createdAt = note.createdAt,
            updatedAt = note.updatedAt,
            isSynced = note.isSynced
        )
    }
}
